// Keyboard Typing Sound Effect
document.addEventListener('DOMContentLoaded', function() {
    // Create audio context
    let audioContext;
    let keyboardSound;
    let isAudioInitialized = false;

    // Function to initialize audio
    function initializeAudio() {
        if (isAudioInitialized) return;
        
        try {
            // Create audio context
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            
            // Create audio element
            keyboardSound = new Audio('assets/audio/mixkit-keyboard-typing-1386.wav');
            keyboardSound.volume = 0.5;
            
            // Resume audio context if it's suspended
            if (audioContext.state === 'suspended') {
                audioContext.resume();
            }
            
            isAudioInitialized = true;
            
            // Play initial sound
            playKeyboardSound();
        } catch (error) {
            console.log('Audio initialization failed:', error);
        }
    }

    // Function to play the sound
    function playKeyboardSound() {
        if (!keyboardSound) return;
        
        keyboardSound.currentTime = 0;
        keyboardSound.play().catch(error => {
            console.log('Audio playback failed:', error);
        });
    }
    
    // Initialize audio on first user interaction
    document.addEventListener('click', function initAudio() {
        initializeAudio();
        // Remove the event listener after first interaction
        document.removeEventListener('click', initAudio);
    }, { once: true });
    
    // Also try to initialize on page load
    initializeAudio();
    
    // Add event listeners to interactive elements
    const interactiveElements = document.querySelectorAll('a, button, input, textarea, .social-icons a');
    
    interactiveElements.forEach(element => {
        element.addEventListener('click', playKeyboardSound);
    });
    
    // Add event listener to the animated text
    const animatedText = document.querySelector('.animated-text');
    if (animatedText) {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList') {
                    playKeyboardSound();
                }
            });
        });
        
        observer.observe(animatedText, { childList: true, subtree: true });
    }
}); 